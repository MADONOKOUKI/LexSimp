# -*- coding: utf-8 -*-
from sklearn.svm import SVR
from sklearn import neighbors
from sklearn.ensemble import RandomForestRegressor
import numpy as np
import scipy 
import matplotlib.pyplot as plt
import sys
from sklearn import linear_model,preprocessing # scikit-learn の Linear Regression を利用します
from collections import OrderedDict
# from sklearn.datasets.samples_generator import make_regression # 回帰用のサンプルデータ


def predict_Y_by_scv(test_csv,train_csv):
  l = [2, 3, 4, 5, 6, 7, 8, 9, 11, 12,13,14,15,16,17,18,19,20,21,22,24,25,26,27,28,29]
  x_train = np.loadtxt(train_csv,dtype=(float),delimiter=',',usecols=l)
  y_train = np.loadtxt(train_csv,dtype=(float),delimiter=',',usecols=30)
  x_test = np.loadtxt(test_csv,dtype=(float),delimiter=',',usecols=l)
  # y_test = np.loadtxt(test_csv,dtype=(float),delimiter=',',usecols=17)
  clf = MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(5, 2), random_state=1)
  clf.fit(x_train,y_train)    
   y_test = clf.predict(x_test)
  # regr = linear_model.LinearRegression()
  # regr.fit(x_train,y_train)  # 訓練する
  # y_test = regr.predict(x_test)
  x_test = np.loadtxt(test_csv,dtype=(str),delimiter=',',usecols=(0,1,2))
  # x_test2 = np.loadtxt(test_csv,dtype=(str),delimiter=',',usecols=1)
  text = ''
  cnt = 0
  for i in range(1,301):
    total_score = []
    l = 0
    # print("Sentence "+str(i)+" rankings: ")
    #tokenize
    # if(cnt > len(x_test)-1):
    #     break
    rank = dict()
    text+="Sentence "+str(i)+" rankings: " 
    while(float(x_test[cnt][0]) == float(i)-1):
    # while(float(x_test[cnt][0]) == float(i)-301):
      if(y[cnt] == 1):
        if x_test[cnt][1] not in rank:
          rank[x_test[cnt][1]] = 1
        else :
          rank[x_test[cnt][1]] += 1
      else if(y[cnt] == -1):
        if x_test[cnt][2] not in rank:
          rank[x_test[cnt][2]] = 1
        else :
          rank[x_test[cnt][2]] += 1
      cnt += 1
      if(cnt > len(x_test)-1):
        break
    OrderedDict(sorted(rank.items(),reverse = True))
    # for j in range(0,l):
    for key,idx in enumerate(rank.iterkeys()):
      text += "{" + key + "}"
      if(len(rank)-1 != idx): text += " "
    text+='\n'
    # csvWriter.writerow(all_listData)
  return text

if __name__ == '__main__':
  argvs = sys.argv
  # check_argvs(argvs)
  #xmlとsubstitution読み込み
  # print(argvs)
  train_csv = argvs[1]
  test_csv =  argvs[2]
  # try:
  print(predict_Y_by_scv(train_csv,test_csv))
  #  rint("Oops!  That was mistakes.  Try again...")