# -*- coding: utf-8 -*-
from sklearn.svm import SVR
from sklearn import neighbors
from sklearn.ensemble import RandomForestRegressor
import numpy as np
import scipy 
import matplotlib.pyplot as plt
import sys
from sklearn import linear_model,preprocessing # scikit-learn の Linear Regression を利用します
# from sklearn.datasets.samples_generator import make_regression # 回帰用のサンプルデータ


def predict_Y_by_scv(test_csv,train_csv):
  l = [2, 3, 4, 5, 6, 7, 8, 10, 11, 12]
  x_train = np.loadtxt(train_csv,dtype=(float),delimiter=',',usecols=l)
  y_train = np.loadtxt(train_csv,dtype=(float),delimiter=',',usecols=17)
  x_test = np.loadtxt(test_csv,dtype=(float),delimiter=',',usecols=l)
  # y_test = np.loadtxt(test_csv,dtype=(float),delimiter=',',usecols=17)
  regr = linear_model.LinearRegression()
  regr.fit(x_train,y_train)  # 訓練する
  y_test = regr.predict(x_test)
  x_test = np.loadtxt(test_csv,dtype=(str),delimiter=',',usecols=(0,1))
  # x_test2 = np.loadtxt(test_csv,dtype=(str),delimiter=',',usecols=1)
  text = ''
  cnt = 0
  for i in range(1,301):
    total_score = []
    l = 0
    # print("Sentence "+str(i)+" rankings: ")
    #tokenize
    # if(cnt > len(x_test)-1):
    #     break
    text+="Sentence "+str(i)+" rankings: " 
    while(float(x_test[cnt][0]) == float(i)-1):
    # while(float(x_test[cnt][0]) == float(i)-301):
      total_score.append([x_test[cnt][1],y_test[cnt]])
      cnt += 1
      l += 1
      if(cnt > len(x_test)-1):
        break
    sorted(total_score,key=lambda x: x[1]) #　タプルの数字が小さい順にソート
    for j in range(0,l):
      # print(total_score[j][0])
          # retrieve phrase indicate meaning (not a word or an idiom)
          # method find return -1 if pharase don't include designate character 
          # if(total_score[j][1].find('_',0,len(total_score[j][1])) != -1): continue
      text += "{" + total_score[j][0] + "}"
      if(len(total_score)-1 != j): text += " "
    text+='\n'

    # csvWriter.writerow(all_listData)
  return text

if __name__ == '__main__':
  argvs = sys.argv
  # check_argvs(argvs)
  #xmlとsubstitution読み込み
  # print(argvs)
  train_csv = argvs[1]
  test_csv =  argvs[2]
  # try:
  print(predict_Y_by_scv(train_csv,test_csv))
  #  rint("Oops!  That was mistakes.  Try again...")